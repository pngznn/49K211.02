// controllers/khoaController.js
const db = require('../config/db');

// ── Helper: parse số nguyên an toàn ──────────────────────
const toInt = (v, fallback) => {
  const n = parseInt(v, 10);
  return isNaN(n) ? fallback : n;
};

// GET /api/khoa
// Query: ?page=1&limit=10&search=nội
exports.getAll = async (req, res) => {
  try {
    const page   = toInt(req.query.page,   1);
    const limit  = toInt(req.query.limit, 10);
    const search = (req.query.search || '').trim();
    const offset = (page - 1) * limit;

    let where  = '';
    let params = [];

    if (search) {
      where  = 'WHERE ten_khoa LIKE ? OR truong_khoa LIKE ?';
      params = [`%${search}%`, `%${search}%`];
    }

    // Đếm tổng để tính trang
    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) AS total FROM khoa ${where}`,
      params
    );

    // Kèm số lượng bác sĩ mỗi khoa
    const [rows] = await db.query(
      `SELECT k.*,
              COUNT(b.id) AS so_bac_si
       FROM khoa k
       LEFT JOIN bac_si b ON b.khoa_id = k.id
       ${where}
       GROUP BY k.id
       ORDER BY k.id
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    res.json({
      success: true,
      data: rows,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/khoa/:id
exports.getById = async (req, res) => {
  try {
    const [[khoa]] = await db.query(
      `SELECT k.*, COUNT(b.id) AS so_bac_si
       FROM khoa k
       LEFT JOIN bac_si b ON b.khoa_id = k.id
       WHERE k.id = ?
       GROUP BY k.id`,
      [req.params.id]
    );

    if (!khoa) return res.status(404).json({ success: false, message: 'Không tìm thấy khoa' });

    res.json({ success: true, data: khoa });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /api/khoa
exports.create = async (req, res) => {
  try {
    const { ten_khoa, mo_ta, truong_khoa } = req.body;

    if (!ten_khoa || !ten_khoa.trim()) {
      return res.status(400).json({ success: false, message: 'Tên khoa không được để trống' });
    }

    const [result] = await db.query(
      'INSERT INTO khoa (ten_khoa, mo_ta, truong_khoa) VALUES (?, ?, ?)',
      [ten_khoa.trim(), mo_ta || null, truong_khoa || null]
    );

    res.status(201).json({
      success: true,
      message: 'Tạo khoa thành công',
      data: { id: result.insertId, ten_khoa, mo_ta, truong_khoa },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// PUT /api/khoa/:id
exports.update = async (req, res) => {
  try {
    const { ten_khoa, mo_ta, truong_khoa } = req.body;

    if (!ten_khoa || !ten_khoa.trim()) {
      return res.status(400).json({ success: false, message: 'Tên khoa không được để trống' });
    }

    const [result] = await db.query(
      'UPDATE khoa SET ten_khoa=?, mo_ta=?, truong_khoa=? WHERE id=?',
      [ten_khoa.trim(), mo_ta || null, truong_khoa || null, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy khoa' });
    }

    res.json({ success: true, message: 'Cập nhật khoa thành công' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE /api/khoa/:id
exports.remove = async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM khoa WHERE id=?', [req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy khoa' });
    }

    res.json({ success: true, message: 'Xóa khoa thành công' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
