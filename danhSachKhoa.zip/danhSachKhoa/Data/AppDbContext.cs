﻿using danhSachKhoa.Models;
using Microsoft.EntityFrameworkCore;

namespace danhSachKhoa.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Department> Departments { get; set; }
    }
}