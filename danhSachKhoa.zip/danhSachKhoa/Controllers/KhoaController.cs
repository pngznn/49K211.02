﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;

[ApiController]
[Route("api/[controller]")]
public class KhoaController : ControllerBase
{
    [HttpGet]
    public IActionResult GetAll(string? search)
    {
        var danhSachKhoa = new[]
        {
            new { name = "Khoa Nội", location = "Tầng 2 Toà A", doctors = 12, group = "Khối lâm sàng" },
            new { name = "Khoa Ngoại", location = "Tầng 3 Toà A", doctors = 10, group = "Khối lâm sàng" },
            new { name = "Khoa Nhi", location = "Tầng 3 Toà B", doctors = 18, group = "Khối lâm sàng" },
            new { name = "Khoa Tim Mạch", location = "Tầng 2 Toà A", doctors = 11, group = "Khối lâm sàng" },
            new { name = "Khoa Tiêu Hóa", location = "Tầng 2 Toà A", doctors = 9, group = "Khối lâm sàng" },
            new { name = "Khoa Da Liễu", location = "Tầng 1 Toà B", doctors = 8, group = "Khối lâm sàng" },
            new { name = "Khoa Hô Hấp", location = "Tầng 2 Toà B", doctors = 7, group = "Khối lâm sàng" },
            new { name = "Khoa Tai Mũi Họng", location = "Tầng 1 Toà B", doctors = 6, group = "Khối lâm sàng" },
            new { name = "Khoa Sản", location = "Tầng 3 Toà B", doctors = 10, group = "Khối lâm sàng" },
            new { name = "Khoa Răng Hàm Mặt", location = "Tầng 1 Toà B", doctors = 8, group = "Khối lâm sàng" },
            new { name = "Khoa Thần Kinh", location = "Tầng 2 Toà A", doctors = 7, group = "Khối lâm sàng" },
            new { name = "Khoa Tiết Niệu", location = "Tầng 2 Toà B", doctors = 6, group = "Khối lâm sàng" },
            new { name = "Khoa Nam Khoa", location = "Tầng 2 Toà B", doctors = 5, group = "Khối lâm sàng" },
            new { name = "Khoa Ung Bướu", location = "Tầng 3 Toà A", doctors = 9, group = "Khối lâm sàng" },
            new { name = "Khoa Chấn Thương Chỉnh Hình", location = "Tầng 3 Toà A", doctors = 8, group = "Khối lâm sàng" },
            new { name = "Khoa Hồi Sức Cấp Cứu", location = "Tầng 1 Toà A", doctors = 12, group = "Khối lâm sàng" },

            new { name = "Khoa Chẩn Đoán Hình Ảnh", location = "Tầng 1 Toà C", doctors = 10, group = "Khối cận lâm sàng" },

            new { name = "Khoa Dinh Dưỡng", location = "Tầng 2 Toà B", doctors = 6, group = "Khối hỗ trợ" },
            new { name = "Khoa Vật Lý Trị Liệu", location = "Tầng 2 Toà B", doctors = 7, group = "Khối hỗ trợ" }
        };

        if (!string.IsNullOrEmpty(search))
        {
            danhSachKhoa = danhSachKhoa
                .Where(k => k.name.ToLower().Contains(search.ToLower()))
                .ToArray();
        }

        return Ok(danhSachKhoa);
    }
}