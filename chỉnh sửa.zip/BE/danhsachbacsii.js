// ─── CliniCare - Danh sách bác sĩ ───────────────────────────────────────────

const TRASH = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <polyline points="3 6 5 6 21 6"/>
  <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
  <path d="M10 11v6M14 11v6"/>
  <path d="M9 6V4h6v2"/>
</svg>`;

let rowToDelete = null;
let toastTimer = null;

// ─── MODAL ───────────────────────────────────────────────────────────────────

/**
 * Mở modal thêm bác sĩ, reset toàn bộ form.
 */
function openAddModal() {
  ['inputName', 'inputPhone', 'inputEmail'].forEach(id => {
    const el = document.getElementById(id);
    el.value = '';
    el.classList.remove('error');
  });
  document.getElementById('inputSpecialty').value = '';
  document.getElementById('inputSpecialty').classList.remove('error');

  document.getElementById('addModal').classList.add('open');
  setTimeout(() => document.getElementById('inputName').focus(), 150);
}

/**
 * Mở modal xác nhận xóa, lưu lại dòng cần xóa.
 * @param {HTMLElement} btn - Nút xóa được nhấn
 */
function openDeleteModal(btn) {
  rowToDelete = btn.closest('tr');
  document.getElementById('deleteTargetName').textContent =
    rowToDelete.querySelector('.name').textContent;
  document.getElementById('deleteModal').classList.add('open');
}

/**
 * Đóng modal theo id.
 * @param {string} id - ID của modal overlay
 */
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// ─── THÊM BÁC SĨ ─────────────────────────────────────────────────────────────

/**
 * Validate form và thêm hàng bác sĩ mới vào bảng.
 */
function addDoctor() {
  const name = document.getElementById('inputName').value.trim();
  const specialty = document.getElementById('inputSpecialty').value;

  // Validate
  let hasError = false;
  if (!name) {
    document.getElementById('inputName').classList.add('error');
    hasError = true;
  }
  if (!specialty) {
    document.getElementById('inputSpecialty').classList.add('error');
    hasError = true;
  }
  if (hasError) return;

  const phone = document.getElementById('inputPhone').value.trim();
  const email = document.getElementById('inputEmail').value.trim();

  // Tạo hàng mới
  const tbody = document.getElementById('doctorTableBody');
  const stt = tbody.querySelectorAll('tr').length + 1;
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td class="stt">${stt}</td>
    <td class="name">${name}</td>
    <td class="specialty">${specialty}</td>
    <td class="phone">${phone || '—'}</td>
    <td class="email">${email || '—'}</td>
    <td class="actions">
      <button class="btn-delete" onclick="openDeleteModal(this)">
        ${TRASH}Xóa
      </button>
    </td>
  `;
  tbody.appendChild(tr);

  updateCount();
  closeModal('addModal');
  showToast(`Đã thêm ${name} thành công!`);
}

// ─── XÓA BÁC SĨ ──────────────────────────────────────────────────────────────

/**
 * Xác nhận xóa: xóa hàng, cập nhật STT và đếm.
 */
function confirmDelete() {
  if (!rowToDelete) return;

  const name = rowToDelete.querySelector('.name').textContent;
  rowToDelete.remove();
  reindex();
  updateCount();
  rowToDelete = null;

  closeModal('deleteModal');
  showToast(`Đã xóa ${name} khỏi danh sách.`);
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

/**
 * Đánh lại số thứ tự (STT) cho toàn bộ hàng trong bảng.
 */
function reindex() {
  document.querySelectorAll('#doctorTableBody tr').forEach((tr, i) => {
    tr.querySelector('.stt').textContent = i + 1;
  });
}

/**
 * Cập nhật số đếm bác sĩ ở header bảng và info card.
 */
function updateCount() {
  const n = document.querySelectorAll('#doctorTableBody tr').length;
  document.getElementById('doctorCount').textContent = n;
  document.getElementById('cardCount').textContent = n + ' bác sĩ';
}

// ─── TOAST ───────────────────────────────────────────────────────────────────

/**
 * Hiện toast thông báo góc trên bên phải, tự mất sau 3.5 giây.
 * @param {string} msg - Nội dung thông báo
 */
function showToast(msg) {
  const toast = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3500);
}

/**
 * Đóng toast thủ công (nút X).
 */
function hideToast() {
  document.getElementById('toast').classList.remove('show');
  clearTimeout(toastTimer);
}

// ─── INIT ─────────────────────────────────────────────────────────────────────

// Đóng modal khi click ra ngoài overlay
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

// Xóa trạng thái lỗi khi người dùng bắt đầu nhập
['inputName', 'inputSpecialty'].forEach(id => {
  document.getElementById(id).addEventListener('input', function () {
    this.classList.remove('error');
  });
});
