-- =====================================================
--  CHẠY FILE NÀY TRONG MySQL Workbench
--  Ctrl + Shift + Enter  để chạy toàn bộ
-- =====================================================

CREATE DATABASE IF NOT EXISTS clinicare
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE clinicare;

-- ── Bảng bác sĩ (nếu chưa có) ──────────────────────
CREATE TABLE IF NOT EXISTS bac_si (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  ma           VARCHAR(20)  NOT NULL UNIQUE,
  ho_ten       VARCHAR(100) NOT NULL,
  gioi_tinh    VARCHAR(10),
  ngay_sinh    DATE,
  dien_thoai   VARCHAR(20),
  email        VARCHAR(100),
  khoa         VARCHAR(100),
  chuyen_mon   VARCHAR(100),
  chuc_danh    VARCHAR(50),
  kinh_nghiem  INT DEFAULT 0,
  ngay_vao_lam DATE,
  dia_chi      TEXT,
  gioi_thieu   TEXT,
  mo_ta        TEXT,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Bảng khung giờ khám ────────────────────────────
-- Mỗi row = 1 slot của 1 bác sĩ trong 1 ngày trong tuần
CREATE TABLE IF NOT EXISTS khung_gio_kham (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  bac_si_ma  VARCHAR(20) NOT NULL,
  thu        ENUM('t2','t3','t4','t5','t6','t7','cn') NOT NULL,
  gio_bat_dau TIME NOT NULL,         -- VD: 08:00:00
  gio_ket_thuc TIME NOT NULL,        -- VD: 09:00:00
  trang_thai ENUM('trong','da_dat') DEFAULT 'trong',
  ghi_chu    VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (bac_si_ma) REFERENCES bac_si(ma) ON DELETE CASCADE,
  UNIQUE KEY unique_slot (bac_si_ma, thu, gio_bat_dau)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Dữ liệu mẫu bác sĩ ─────────────────────────────
INSERT INTO bac_si (ma, ho_ten, gioi_tinh, ngay_sinh, dien_thoai, email, khoa, chuyen_mon, chuc_danh, kinh_nghiem, ngay_vao_lam, dia_chi, gioi_thieu, mo_ta)
VALUES (
  'BS001', 'BS. Nguyễn Văn An', 'Nam', '1985-03-15',
  '0901234567', 'nva@clinicare.vn',
  'Khoa Nội', 'Nội tổng quát', 'Bác Sĩ', 5, '2024-01-15',
  'Số 123 Đường Nguyễn Huệ, Quận 1, TP. Hồ Chí Minh',
  'Bác sĩ chuyên khoa với nhiều năm kinh nghiệm trong lĩnh vực điều trị và chăm sóc sức khỏe người bệnh.',
  'Chuyên sâu về nội tổng quát, có kinh nghiệm điều trị các bệnh lý phức tạp và quản lý các ca bệnh khó.'
);

-- ── Dữ liệu mẫu khung giờ khám cho BS001 ───────────
-- Thứ 2
INSERT INTO khung_gio_kham (bac_si_ma, thu, gio_bat_dau, gio_ket_thuc, trang_thai) VALUES
('BS001','t2','08:00','09:00','trong'),
('BS001','t2','09:00','10:00','da_dat'),
('BS001','t2','10:00','11:00','trong'),
('BS001','t2','11:00','12:00','da_dat'),
('BS001','t2','13:00','14:00','trong'),
('BS001','t2','14:00','15:00','da_dat'),
('BS001','t2','15:00','16:00','trong'),
('BS001','t2','16:00','17:00','da_dat'),
-- Thứ 3
('BS001','t3','08:00','09:00','trong'),
('BS001','t3','09:00','10:00','trong'),
('BS001','t3','10:00','11:00','da_dat'),
('BS001','t3','11:00','12:00','trong'),
('BS001','t3','13:00','14:00','trong'),
('BS001','t3','14:00','15:00','da_dat'),
('BS001','t3','15:00','16:00','trong'),
('BS001','t3','16:00','17:00','trong'),
-- Thứ 4
('BS001','t4','08:00','09:00','da_dat'),
('BS001','t4','09:00','10:00','trong'),
('BS001','t4','10:00','11:00','trong'),
('BS001','t4','11:00','12:00','da_dat'),
('BS001','t4','13:00','14:00','trong'),
('BS001','t4','14:00','15:00','trong'),
('BS001','t4','15:00','16:00','da_dat'),
('BS001','t4','16:00','17:00','trong'),
-- Thứ 5
('BS001','t5','08:00','09:00','trong'),
('BS001','t5','09:00','10:00','da_dat'),
('BS001','t5','10:00','11:00','trong'),
('BS001','t5','11:00','12:00','trong'),
('BS001','t5','13:00','14:00','da_dat'),
('BS001','t5','14:00','15:00','da_dat'),
('BS001','t5','15:00','16:00','trong'),
('BS001','t5','16:00','17:00','trong'),
-- Thứ 6
('BS001','t6','08:00','09:00','trong'),
('BS001','t6','09:00','10:00','trong'),
('BS001','t6','10:00','11:00','da_dat'),
('BS001','t6','11:00','12:00','trong'),
('BS001','t6','13:00','14:00','trong'),
('BS001','t6','14:00','15:00','da_dat'),
('BS001','t6','15:00','16:00','trong'),
('BS001','t6','16:00','17:00','da_dat'),
-- Thứ 7
('BS001','t7','08:00','09:00','trong'),
('BS001','t7','09:00','10:00','trong'),
('BS001','t7','10:00','11:00','trong'),
('BS001','t7','11:00','12:00','da_dat'),
('BS001','t7','13:00','14:00','trong'),
('BS001','t7','14:00','15:00','trong'),
('BS001','t7','15:00','16:00','da_dat'),
('BS001','t7','16:00','17:00','trong');

-- Kiểm tra
SELECT * FROM bac_si;
SELECT * FROM khung_gio_kham WHERE bac_si_ma = 'BS001' ORDER BY thu, gio_bat_dau;
