﻿namespace BE_DsKhoa.Models
{
    public class Khoa
    {
        public int Id { get; set; }
        public string? TenKhoa { get; set; }
        public string? MoTa { get; set; }
    }
}