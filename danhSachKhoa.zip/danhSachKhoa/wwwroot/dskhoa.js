console.log("JS ĐANG CHẠY");

document.addEventListener('DOMContentLoaded', () => {

    const deptGrid = document.querySelector('.dept-grid');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const searchInput = document.querySelector('.search-bar input');

    let departments = []; // 👈 để rỗng, sẽ lấy từ API

    // ===== LOAD API =====
    function loadData() {
        deptGrid.innerHTML = `<p>Đang tải dữ liệu...</p>`;

        fetch("/api/khoa")
            .then(res => res.json())
            .then(data => {
                console.log("DATA:", data); // 👈 check

                departments = data; // 👈 gán data từ BE

                renderDepartments(departments);
            })
            .catch(err => {
                console.error(err);
                deptGrid.innerHTML = `<p style="color:red">Lỗi load dữ liệu</p>`;
            });
    }

    // ===== RENDER =====
    function renderDepartments(data) {
        if (!data || data.length === 0) {
            deptGrid.innerHTML = `<p>Không có khoa nào</p>`;
            return;
        }

        deptGrid.innerHTML = '';

        data.forEach(dept => {
            const card = document.createElement('div');
            card.className = 'dept-card';

            card.innerHTML = `
                <div class="dept-name">${dept.name}</div>
                <div class="dept-info">Vị trí: ${dept.location}</div>
                <div class="dept-info">Số lượng Bác sĩ: ${dept.doctors}</div>
            `;

            deptGrid.appendChild(card);
        });
    }

    // ===== FILTER =====
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelector('.filter-btn.active').classList.remove('active');
            btn.classList.add('active');

            const group = btn.textContent.trim();

            if (group === 'Tất cả') {
                renderDepartments(departments);
            } else {
                const filtered = departments.filter(d => d.group === group);
                renderDepartments(filtered);
            }
        });
    });

    // ===== SEARCH =====
    searchInput.addEventListener('input', (e) => {
        const keyword = e.target.value.toLowerCase();

        const filtered = departments.filter(dept =>
            dept.name.toLowerCase().includes(keyword)
        );

        renderDepartments(filtered);
    });

    // 🚀 QUAN TRỌNG NHẤT
    loadData(); // 👈 GỌI API

});