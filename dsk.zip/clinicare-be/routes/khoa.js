const express = require('express');
const router  = express.Router();
const db      = require('../db');

// ─────────────────────────────────────────────
//  GET /api/khoa
//  Lấy danh sách khoa, hỗ trợ tìm kiếm ?q=...
// ─────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { q } = req.query;
    let sql    = 'SELECT * FROM khoa';
    let params = [];

    if (q && q.trim()) {
      sql   += ' WHERE ma LIKE ? OR ten LIKE ? OR truong LIKE ?';
      const kw = `%${q.trim()}%`;
      params   = [kw, kw, kw];
    }

    sql += ' ORDER BY id ASC';

    const [rows] = await db.query(sql, params);

    // Thống kê tổng (không bị ảnh hưởng bởi filter)
    const [[{ tongKhoa }]] = await db.query('SELECT COUNT(*) AS tongKhoa FROM khoa');
    const [[{ tongBS   }]] = await db.query('SELECT COALESCE(SUM(so_bs),0) AS tongBS FROM khoa');

    // Đổi tên cột so_bs → soBS cho FE dùng
    const data = rows.map(r => ({
      id:     r.id,
      ma:     r.ma,
      ten:    r.ten,
      truong: r.truong,
      soBS:   r.so_bs,
      moTa:   r.mo_ta || '',
    }));

    res.json({ success: true, data, tongKhoa, tongBS });
  } catch (err) {
    console.error('GET /api/khoa lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

// ─────────────────────────────────────────────
//  POST /api/khoa
//  Thêm khoa mới
// ─────────────────────────────────────────────
router.post('/', async (req, res) => {
  try {
    const { ma, ten, truong, soBS, moTa } = req.body;

    // Validate bắt buộc
    if (!ma || !ten || !truong) {
      return res.status(400).json({
        success: false,
        message: 'Vui lòng nhập đầy đủ: mã khoa, tên khoa, trưởng khoa',
      });
    }

    const maChuanHoa = ma.trim().toUpperCase();

    // Kiểm tra mã trùng
    const [dup] = await db.query('SELECT id FROM khoa WHERE ma = ?', [maChuanHoa]);
    if (dup.length > 0) {
      return res.status(409).json({
        success: false,
        message: `Mã khoa "${maChuanHoa}" đã tồn tại`,
      });
    }

    const [result] = await db.query(
      'INSERT INTO khoa (ma, ten, truong, so_bs, mo_ta) VALUES (?, ?, ?, ?, ?)',
      [maChuanHoa, ten.trim(), truong.trim(), Number(soBS) || 0, moTa?.trim() || null]
    );

    res.status(201).json({
      success: true,
      message: 'Thêm khoa thành công',
      data: {
        id:     result.insertId,
        ma:     maChuanHoa,
        ten:    ten.trim(),
        truong: truong.trim(),
        soBS:   Number(soBS) || 0,
      },
    });
  } catch (err) {
    console.error('POST /api/khoa lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

// ─────────────────────────────────────────────
//  DELETE /api/khoa/:ma
//  Xóa khoa theo mã
// ─────────────────────────────────────────────
router.delete('/:ma', async (req, res) => {
  try {
    const ma = req.params.ma.toUpperCase();

    const [rows] = await db.query('SELECT * FROM khoa WHERE ma = ?', [ma]);
    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Không tìm thấy khoa có mã "${ma}"`,
      });
    }

    await db.query('DELETE FROM khoa WHERE ma = ?', [ma]);

    res.json({
      success: true,
      message: `Đã xóa khoa "${rows[0].ten}" thành công`,
      data: { ma: rows[0].ma, ten: rows[0].ten },
    });
  } catch (err) {
    console.error('DELETE /api/khoa lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

module.exports = router;
