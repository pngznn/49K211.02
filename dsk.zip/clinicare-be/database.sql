-- ================================================
--  CHẠY FILE NÀY TRONG MySQL Workbench
--  Query > Execute All  hoặc  Ctrl+Shift+Enter
-- ================================================

CREATE DATABASE IF NOT EXISTS clinicare
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE clinicare;

CREATE TABLE IF NOT EXISTS khoa (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  ma         VARCHAR(10)  NOT NULL UNIQUE,
  ten        VARCHAR(100) NOT NULL,
  truong     VARCHAR(100) NOT NULL,
  so_bs      INT          NOT NULL DEFAULT 0,
  mo_ta      TEXT,
  created_at DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dữ liệu mẫu (khớp đúng với file HTML của bạn)
INSERT INTO khoa (ma, ten, truong, so_bs) VALUES
  ('NK',   'Nội',                      'BS. Hoàng Văn Em',    7),
  ('NG',   'Ngoại',                    'BS. Vũ Thị Phương',   9),
  ('NHI',  'Nhi',                      'BS. Trần Thị Bình',   6),
  ('TM',   'Tim mạch',                 'BS. Nguyễn Văn An',   8),
  ('TH',   'Tiêu hóa',                 'BS. Lý Văn Hùng',     5),
  ('DL',   'Da liễu',                  'BS. Phạm Thị Dung',   4),
  ('HH',   'Hô hấp',                   'BS. Ngô Văn Khoa',    5),
  ('TMH',  'Tai mũi họng',             'BS. Bùi Thị Hoa',     5),
  ('SS',   'Sản',                      'BS. Ngô Thị Lan',     6),
  ('RHM',  'Răng hàm mặt',            'BS. Đặng Văn Long',   4),
  ('TK',   'Thần kinh',                'BS. Lê Văn Cường',    5),
  ('TTN',  'Tiết niệu',               'BS. Trịnh Văn Nam',   4),
  ('NAM',  'Nam khoa',                 'BS. Phan Văn Oanh',   3),
  ('UB',   'Ung bướu',                 'BS. Cao Thị Phúc',    6),
  ('CTCH', 'Chấn thương chỉnh hình',  'BS. Vương Văn Quân',  7),
  ('HSCC', 'Hồi sức cấp cứu',         'BS. Mai Thị Rồng',    8),
  ('CDHA', 'Chẩn đoán hình ảnh',      'BS. Lưu Văn Sơn',     5),
  ('DDD',  'Dinh dưỡng',              'BS. Hà Thị Tâm',      3),
  ('VLTT', 'Vật lý trị liệu',         'BS. Đinh Văn Uy',     4);

-- Kiểm tra kết quả
SELECT * FROM khoa;
