// server.js
require('dotenv').config();
const express = require('express');
const cors    = require('cors');

const khoaRoutes  = require('./routes/khoa');
const bacSiRoutes = require('./routes/bacSi');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ─────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Routes ─────────────────────────────────────────────────
app.use('/api/khoa',   khoaRoutes);
app.use('/api/bac-si', bacSiRoutes);

// ── Health check ───────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'CliniCare API đang chạy 🚀', time: new Date() });
});

// ── 404 handler ────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} không tồn tại` });
});

// ── Global error handler ───────────────────────────────────
app.use((err, req, res, _next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Lỗi server nội bộ' });
});

// ── Start server ───────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 CliniCare API chạy tại http://localhost:${PORT}`);
  console.log(`📋 Endpoint mẫu:`);
  console.log(`   GET  http://localhost:${PORT}/api/khoa`);
  console.log(`   GET  http://localhost:${PORT}/api/bac-si?khoa_id=1&page=1&search=nội`);
});
