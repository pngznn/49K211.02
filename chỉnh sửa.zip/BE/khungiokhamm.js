var scheduleData = {
  '2': [{t:'08:00',b:false},{t:'09:00',b:true},{t:'10:00',b:false},{t:'11:00',b:true},{t:'13:00',b:false},{t:'14:00',b:true},{t:'15:00',b:false},{t:'16:00',b:true}],
  '3': [{t:'08:00',b:false},{t:'09:00',b:false},{t:'10:00',b:true},{t:'11:00',b:false},{t:'13:00',b:true},{t:'14:00',b:false},{t:'15:00',b:false},{t:'16:00',b:false}],
  '4': [{t:'08:00',b:true},{t:'09:00',b:false},{t:'10:00',b:false},{t:'11:00',b:true},{t:'13:00',b:false},{t:'14:00',b:false},{t:'15:00',b:true},{t:'16:00',b:false}],
  '5': [{t:'08:00',b:false},{t:'09:00',b:true},{t:'10:00',b:true},{t:'11:00',b:false},{t:'13:00',b:false},{t:'14:00',b:true},{t:'15:00',b:false},{t:'16:00',b:false}],
  '6': [{t:'08:00',b:false},{t:'09:00',b:false},{t:'10:00',b:false},{t:'11:00',b:false},{t:'13:00',b:true},{t:'14:00',b:false},{t:'15:00',b:true},{t:'16:00',b:false}],
  '7': [{t:'08:00',b:false},{t:'09:00',b:true},{t:'10:00',b:false},{t:'11:00',b:false},{t:'13:00',b:false},{t:'14:00',b:false},{t:'15:00',b:false},{t:'16:00',b:true}]
};

function renderSlots(day) {
  var grid = document.getElementById('slotsGrid');
  var slots = scheduleData[day] || [];
  var html = '';
  for (var i = 0; i < slots.length; i++) {
    var s = slots[i];
    html += '<div class="slot' + (s.b ? ' booked' : '') + '">' + s.t + '</div>';
  }
  grid.innerHTML = html;
}

function selectDay(el, day) {
  var tabs = document.querySelectorAll('.day-tab');
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove('active');
  el.classList.add('active');
  renderSlots(day);
}

function openModal(n) { document.getElementById('modal-' + n).classList.add('open'); }
function closeModal(n) { document.getElementById('modal-' + n).classList.remove('open'); }
function saveModal(n, msg) { closeModal(n); showToast(msg); }

function showToast(msg) {
  var t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(function() { t.classList.remove('show'); }, 2800);
}

document.addEventListener('DOMContentLoaded', function() {
  var overlays = document.querySelectorAll('.modal-overlay');
  for (var i = 0; i < overlays.length; i++) {
    overlays[i].addEventListener('click', function(e) {
      if (e.target === this) this.classList.remove('open');
    });
  }
});
