var TRASH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>';
var rowToDelete = null;
var toastTimer = null;

function openAddModal() {
  ['inputTenKhoa', 'inputMaKhoa', 'inputTruongKhoa', 'inputSoBacSi'].forEach(function(id) {
    var el = document.getElementById(id);
    el.value = '';
    el.classList.remove('error');
  });
  document.getElementById('addModal').classList.add('open');
  setTimeout(function() { document.getElementById('inputTenKhoa').focus(); }, 150);
}

function openDeleteModal(btn) {
  rowToDelete = btn.closest('tr');
  document.getElementById('deleteTargetName').textContent = rowToDelete.querySelector('.ten-khoa').textContent;
  document.getElementById('deleteModal').classList.add('open');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

function addKhoa() {
  var ten = document.getElementById('inputTenKhoa').value.trim();
  var ma = document.getElementById('inputMaKhoa').value.trim();
  var hasError = false;

  if (!ten) { document.getElementById('inputTenKhoa').classList.add('error'); hasError = true; }
  if (!ma)  { document.getElementById('inputMaKhoa').classList.add('error'); hasError = true; }
  if (hasError) return;

  var truong = document.getElementById('inputTruongKhoa').value.trim();
  var so     = document.getElementById('inputSoBacSi').value.trim();
  var tbody  = document.getElementById('khoaTableBody');
  var stt    = tbody.querySelectorAll('tr').length + 1;

  var tr = document.createElement('tr');
  tr.innerHTML =
    '<td class="stt">' + stt + '</td>' +
    '<td class="ma-khoa">' + ma + '</td>' +
    '<td class="ten-khoa">' + ten + '</td>' +
    '<td class="truong-khoa">' + (truong || '—') + '</td>' +
    '<td class="so-bac-si">' + (so || '0') + '</td>' +
    '<td class="actions"><button class="btn-delete" onclick="openDeleteModal(this)">' + TRASH + 'Xóa</button></td>';

  tbody.appendChild(tr);
  updateCount();
  closeModal('addModal');
  showToast('Đã thêm khoa ' + ten + ' thành công!');
}

function confirmDelete() {
  if (!rowToDelete) return;
  var name = rowToDelete.querySelector('.ten-khoa').textContent;
  rowToDelete.remove();
  reindex();
  updateCount();
  rowToDelete = null;
  closeModal('deleteModal');
  showToast('Đã xóa khoa ' + name + ' khỏi danh sách.');
}

function reindex() {
  var rows = document.querySelectorAll('#khoaTableBody tr');
  for (var i = 0; i < rows.length; i++) {
    rows[i].querySelector('.stt').textContent = i + 1;
  }
}

function updateCount() {
  var n = document.querySelectorAll('#khoaTableBody tr').length;
  document.getElementById('totalKhoa').textContent = n;
}

function filterTable() {
  var q = document.getElementById('searchInput').value.toLowerCase();
  var rows = document.querySelectorAll('#khoaTableBody tr');
  for (var i = 0; i < rows.length; i++) {
    var text = rows[i].textContent.toLowerCase();
    rows[i].style.display = text.includes(q) ? '' : 'none';
  }
}

function showToast(msg) {
  var t = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function() { t.classList.remove('show'); }, 3500);
}

function hideToast() {
  document.getElementById('toast').classList.remove('show');
  clearTimeout(toastTimer);
}

document.addEventListener('DOMContentLoaded', function() {
  // Đóng modal khi click ra ngoài
  document.querySelectorAll('.modal-overlay').forEach(function(o) {
    o.addEventListener('click', function(e) {
      if (e.target === o) o.classList.remove('open');
    });
  });

  // Xóa lỗi khi người dùng nhập lại
  ['inputTenKhoa', 'inputMaKhoa'].forEach(function(id) {
    document.getElementById(id).addEventListener('input', function() {
      this.classList.remove('error');
    });
  });
});
