require('dotenv').config();
const express     = require('express');
const cors        = require('cors');
const bacSiRoutes  = require('./routes/bacsi');
const khungGioRoutes = require('./routes/khunggio');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// ── Routes ──────────────────────────────────────────
app.use('/api/bacsi',    bacSiRoutes);
app.use('/api/khunggio', khungGioRoutes);

// Route test
app.get('/', (req, res) => {
  res.json({
    message: '✅ CliniCare API đang chạy!',
    routes: {
      bacSi:    'GET /api/bacsi/:ma',
      khungGio: 'GET /api/khunggio/:bacSiMa  |  GET /api/khunggio/:bacSiMa/:thu',
      them:     'POST /api/khunggio',
      capNhat:  'PUT /api/khunggio/:id',
      xoa:      'DELETE /api/khunggio/:id',
    }
  });
});

app.listen(PORT, () => {
  console.log('');
  console.log('================================================');
  console.log('  🚀 CliniCare Backend đang chạy!');
  console.log(`  📡 Server   : http://localhost:${PORT}`);
  console.log(`  👨‍⚕️  Bác sĩ  : http://localhost:${PORT}/api/bacsi/BS001`);
  console.log(`  🕐 Lịch khám: http://localhost:${PORT}/api/khunggio/BS001`);
  console.log('================================================');
  console.log('');
});
