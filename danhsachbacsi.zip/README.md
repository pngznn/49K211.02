# CliniCare Backend API

Backend Node.js + Express + MySQL cho hệ thống quản lý khoa và bác sĩ.

## Cấu trúc thư mục

```
clinicare-backend/
├── config/
│   └── db.js                 # Kết nối MySQL (connection pool)
├── controllers/
│   ├── khoaController.js     # Logic xử lý Khoa
│   └── bacSiController.js    # Logic xử lý Bác sĩ
├── routes/
│   ├── khoa.js               # Routes /api/khoa
│   └── bacSi.js              # Routes /api/bac-si
├── database/
│   └── schema.sql            # Tạo bảng + dữ liệu mẫu
├── .env.example              # Mẫu biến môi trường
├── package.json
└── server.js                 # Entry point
```

## Cài đặt

```bash
# 1. Cài dependencies
npm install

# 2. Tạo file .env
cp .env.example .env
# Chỉnh sửa thông tin DB trong .env

# 3. Tạo database và dữ liệu mẫu
mysql -u root -p < database/schema.sql

# 4. Chạy server
npm run dev       # development (nodemon)
npm start         # production
```

---

## API Endpoints

### 🏥 Khoa — `/api/khoa`

| Method | URL              | Mô tả                          |
|--------|------------------|--------------------------------|
| GET    | `/api/khoa`      | Lấy danh sách khoa (có lọc/phân trang) |
| GET    | `/api/khoa/:id`  | Lấy chi tiết 1 khoa            |
| POST   | `/api/khoa`      | Tạo khoa mới                   |
| PUT    | `/api/khoa/:id`  | Cập nhật khoa                  |
| DELETE | `/api/khoa/:id`  | Xóa khoa                       |

#### GET `/api/khoa` — Query params

| Param    | Kiểu   | Mặc định | Mô tả                          |
|----------|--------|----------|--------------------------------|
| `page`   | number | 1        | Trang hiện tại                 |
| `limit`  | number | 10       | Số bản ghi mỗi trang           |
| `search` | string | ""       | Tìm theo tên khoa hoặc trưởng khoa |

**Ví dụ:**
```
GET /api/khoa?page=1&limit=5&search=nội
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "ten_khoa": "Nội",
      "mo_ta": "Khoa Nội tổng quát và Nội khoa",
      "truong_khoa": "BS. Nguyễn Văn An",
      "so_bac_si": 12,
      "created_at": "2024-01-01T00:00:00.000Z",
      "updated_at": "2024-01-01T00:00:00.000Z"
    }
  ],
  "pagination": {
    "total": 5,
    "page": 1,
    "limit": 10,
    "totalPages": 1
  }
}
```

#### POST `/api/khoa` — Body

```json
{
  "ten_khoa": "Tim mạch",
  "mo_ta": "Khoa Tim mạch can thiệp",
  "truong_khoa": "BS. Nguyễn Thị A"
}
```

---

### 👨‍⚕️ Bác sĩ — `/api/bac-si`

| Method | URL                | Mô tả                            |
|--------|--------------------|----------------------------------|
| GET    | `/api/bac-si`      | Lấy danh sách bác sĩ (có lọc/phân trang) |
| GET    | `/api/bac-si/:id`  | Lấy chi tiết 1 bác sĩ            |
| POST   | `/api/bac-si`      | Thêm bác sĩ mới                  |
| PUT    | `/api/bac-si/:id`  | Cập nhật bác sĩ                  |
| DELETE | `/api/bac-si/:id`  | Xóa bác sĩ                       |

#### GET `/api/bac-si` — Query params

| Param      | Kiểu   | Mặc định | Mô tả                             |
|------------|--------|----------|-----------------------------------|
| `page`     | number | 1        | Trang hiện tại                    |
| `limit`    | number | 10       | Số bản ghi mỗi trang              |
| `search`   | string | ""       | Tìm theo tên, chuyên môn, email, SĐT |
| `khoa_id`  | number | -        | Lọc theo khoa                     |

**Ví dụ — lấy bác sĩ khoa Nội, trang 1:**
```
GET /api/bac-si?khoa_id=1&page=1&limit=10
```

**Ví dụ — tìm kiếm:**
```
GET /api/bac-si?search=nguyễn&page=1
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "ho_ten": "BS. Nguyễn Văn An",
      "chuyen_mon": "Nội tổng quát",
      "so_dien_thoai": "0901234567",
      "email": "nva@clinicare.vn",
      "khoa_id": 1,
      "ten_khoa": "Nội"
    }
  ],
  "pagination": {
    "total": 12,
    "page": 1,
    "limit": 10,
    "totalPages": 2
  }
}
```

#### POST `/api/bac-si` — Body

```json
{
  "ho_ten": "BS. Nguyễn Thị B",
  "chuyen_mon": "Nội khoa",
  "so_dien_thoai": "0909999999",
  "email": "ntb@clinicare.vn",
  "khoa_id": 1
}
```

---

## Format lỗi

```json
{
  "success": false,
  "message": "Mô tả lỗi cụ thể"
}
```

## Health check

```
GET /api/health
```
