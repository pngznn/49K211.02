-- ============================================================
-- CliniCare - Schema MySQL
-- Chạy file này để tạo database và dữ liệu mẫu
-- mysql -u root -p < database/schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS clinicare
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE clinicare;

-- ── Bảng KHOA ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS khoa (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  ten_khoa    VARCHAR(100) NOT NULL,
  mo_ta       TEXT,
  truong_khoa VARCHAR(100),
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Bảng BAC_SI ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bac_si (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  ho_ten       VARCHAR(100) NOT NULL,
  chuyen_mon   VARCHAR(100),
  so_dien_thoai VARCHAR(20),
  email        VARCHAR(100),
  khoa_id      INT,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (khoa_id) REFERENCES khoa(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Dữ liệu mẫu: KHOA ─────────────────────────────────────
INSERT INTO khoa (ten_khoa, mo_ta, truong_khoa) VALUES
  ('Nội',     'Khoa Nội tổng quát và Nội khoa',       'BS. Nguyễn Văn An'),
  ('Ngoại',   'Khoa Ngoại tổng quát và Phẫu thuật',   'BS. Trần Hữu Bình'),
  ('Nhi',     'Khoa Nhi và Sơ sinh',                  'BS. Lê Thị Cẩm'),
  ('Sản',     'Khoa Sản phụ khoa',                    'BS. Phạm Ngọc Dung'),
  ('Da liễu', 'Khoa Da liễu và Thẩm mỹ',              'BS. Hoàng Văn Em');

-- ── Dữ liệu mẫu: BAC_SI (Khoa Nội - id=1) ────────────────
INSERT INTO bac_si (ho_ten, chuyen_mon, so_dien_thoai, email, khoa_id) VALUES
  ('BS. Nguyễn Văn An',    'Nội tổng quát', '0901234567', 'nva@clinicare.vn',   1),
  ('BS. Trần Thị Mai',     'Nội tổng quát', '0901234568', 'ttm@clinicare.vn',   1),
  ('BS. Lê Hoàng Phúc',    'Nội tổng quát', '0901234569', 'lhp@clinicare.vn',   1),
  ('BS. Phạm Thu Hà',      'Nội khoa',      '0901234570', 'pth@clinicare.vn',   1),
  ('BS. Hoàng Văn Đức',    'Nội tiết',      '0901234571', 'hvd@clinicare.vn',   1),
  ('BS. Võ Thị Lan',       'Nội tổng quát', '0901234572', 'vtl@clinicare.vn',   1),
  ('BS. Đặng Minh Tuấn',   'Nội khoa',      '0901234573', 'dmt@clinicare.vn',   1),
  ('BS. Phan Thị Hương',   'Nội tổng quát', '0901234574', 'pth2@clinicare.vn',  1),
  ('BS. Lý Văn Hải',       'Nội khoa',      '0901234575', 'lvh@clinicare.vn',   1),
  ('BS. Trịnh Thị Ngọc',   'Nội tổng quát', '0901234576', 'ttn@clinicare.vn',   1),
  ('BS. Bùi Văn Nam',      'Nội khoa',      '0901234577', 'bvn@clinicare.vn',   1),
  ('BS. Dương Thị Bích',   'Nội tổng quát', '0901234578', 'dtb@clinicare.vn',   1),
  -- Khoa Ngoại
  ('BS. Ngô Quang Vinh',   'Ngoại tiêu hóa','0902000001', 'nqv@clinicare.vn',   2),
  ('BS. Đinh Thị Hoa',     'Ngoại tổng quát','0902000002','dth@clinicare.vn',   2),
  -- Khoa Nhi
  ('BS. Cao Thị Mỹ',       'Nhi tổng quát', '0903000001', 'ctm@clinicare.vn',   3),
  ('BS. Vũ Đức Long',      'Sơ sinh',       '0903000002', 'vdl@clinicare.vn',   3);
