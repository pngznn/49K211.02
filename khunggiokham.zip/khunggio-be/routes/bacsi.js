const express = require('express');
const router  = express.Router();
const db      = require('../db');

// GET /api/bacsi/:ma  – lấy thông tin 1 bác sĩ
router.get('/:ma', async (req, res) => {
  try {
    const ma = req.params.ma.toUpperCase();
    const [rows] = await db.query('SELECT * FROM bac_si WHERE ma = ?', [ma]);

    if (rows.length === 0)
      return res.status(404).json({ success: false, message: `Không tìm thấy bác sĩ "${ma}"` });

    const r = rows[0];
    res.json({
      success: true,
      data: {
        ma:          r.ma,
        hoTen:       r.ho_ten,
        gioiTinh:    r.gioi_tinh,
        ngaySinh:    r.ngay_sinh,
        dienThoai:   r.dien_thoai,
        email:       r.email,
        khoa:        r.khoa,
        chuyenMon:   r.chuyen_mon,
        chucDanh:    r.chuc_danh,
        kinhNghiem:  r.kinh_nghiem,
        ngayVaoLam:  r.ngay_vao_lam,
        diaChi:      r.dia_chi,
        gioiThieu:   r.gioi_thieu,
        moTa:        r.mo_ta,
      }
    });
  } catch (err) {
    console.error('GET /api/bacsi lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

// GET /api/bacsi  – lấy danh sách bác sĩ (có tìm kiếm)
router.get('/', async (req, res) => {
  try {
    const { q } = req.query;
    let sql = 'SELECT * FROM bac_si';
    let params = [];
    if (q && q.trim()) {
      sql += ' WHERE ma LIKE ? OR ho_ten LIKE ? OR khoa LIKE ?';
      const kw = `%${q.trim()}%`;
      params = [kw, kw, kw];
    }
    sql += ' ORDER BY id ASC';
    const [rows] = await db.query(sql, params);
    res.json({ success: true, data: rows.map(r => ({ ma: r.ma, hoTen: r.ho_ten, khoa: r.khoa, chucDanh: r.chuc_danh })) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

module.exports = router;
