const express = require('express');
const router  = express.Router();
const db      = require('../db');

// ─────────────────────────────────────────────────────
//  GET /api/khunggio/:bacSiMa/:thu
//  Lấy tất cả slot của 1 bác sĩ theo ngày trong tuần
// ─────────────────────────────────────────────────────
router.get('/:bacSiMa/:thu', async (req, res) => {
  try {
    const { bacSiMa, thu } = req.params;
    const [rows] = await db.query(
      `SELECT id, thu,
              TIME_FORMAT(gio_bat_dau,  '%H:%i') AS gioBatDau,
              TIME_FORMAT(gio_ket_thuc, '%H:%i') AS gioKetThuc,
              trang_thai AS trangThai,
              ghi_chu    AS ghiChu
       FROM khung_gio_kham
       WHERE bac_si_ma = ? AND thu = ?
       ORDER BY gio_bat_dau ASC`,
      [bacSiMa.toUpperCase(), thu.toLowerCase()]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('GET /api/khunggio lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

// ─────────────────────────────────────────────────────
//  GET /api/khunggio/:bacSiMa
//  Lấy toàn bộ slot của 1 bác sĩ (tất cả các ngày)
// ─────────────────────────────────────────────────────
router.get('/:bacSiMa', async (req, res) => {
  try {
    const { bacSiMa } = req.params;
    const [rows] = await db.query(
      `SELECT id, thu,
              TIME_FORMAT(gio_bat_dau,  '%H:%i') AS gioBatDau,
              TIME_FORMAT(gio_ket_thuc, '%H:%i') AS gioKetThuc,
              trang_thai AS trangThai,
              ghi_chu    AS ghiChu
       FROM khung_gio_kham
       WHERE bac_si_ma = ?
       ORDER BY FIELD(thu,'t2','t3','t4','t5','t6','t7','cn'), gio_bat_dau ASC`,
      [bacSiMa.toUpperCase()]
    );

    // Nhóm theo ngày để FE dùng dễ hơn
    const grouped = {};
    rows.forEach(r => {
      if (!grouped[r.thu]) grouped[r.thu] = [];
      grouped[r.thu].push(r);
    });

    res.json({ success: true, data: grouped });
  } catch (err) {
    console.error('GET /api/khunggio lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

// ─────────────────────────────────────────────────────
//  POST /api/khunggio
//  Thêm slot mới
//  Body: { bacSiMa, thu, gioBatDau, gioKetThuc, trangThai?, ghiChu? }
// ─────────────────────────────────────────────────────
router.post('/', async (req, res) => {
  try {
    const { bacSiMa, thu, gioBatDau, gioKetThuc, trangThai = 'trong', ghiChu } = req.body;

    if (!bacSiMa || !thu || !gioBatDau || !gioKetThuc)
      return res.status(400).json({ success: false, message: 'Thiếu thông tin bắt buộc: bacSiMa, thu, gioBatDau, gioKetThuc' });

    // Kiểm tra bác sĩ tồn tại
    const [bs] = await db.query('SELECT ma FROM bac_si WHERE ma = ?', [bacSiMa.toUpperCase()]);
    if (bs.length === 0)
      return res.status(404).json({ success: false, message: `Không tìm thấy bác sĩ "${bacSiMa}"` });

    // Kiểm tra slot trùng
    const [dup] = await db.query(
      'SELECT id FROM khung_gio_kham WHERE bac_si_ma = ? AND thu = ? AND gio_bat_dau = ?',
      [bacSiMa.toUpperCase(), thu.toLowerCase(), gioBatDau]
    );
    if (dup.length > 0)
      return res.status(409).json({ success: false, message: `Khung giờ ${gioBatDau} ngày ${thu} đã tồn tại` });

    const [result] = await db.query(
      'INSERT INTO khung_gio_kham (bac_si_ma, thu, gio_bat_dau, gio_ket_thuc, trang_thai, ghi_chu) VALUES (?,?,?,?,?,?)',
      [bacSiMa.toUpperCase(), thu.toLowerCase(), gioBatDau, gioKetThuc, trangThai, ghiChu || null]
    );

    res.status(201).json({
      success: true,
      message: 'Thêm khung giờ thành công',
      data: { id: result.insertId, bacSiMa, thu, gioBatDau, gioKetThuc, trangThai }
    });
  } catch (err) {
    console.error('POST /api/khunggio lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

// ─────────────────────────────────────────────────────
//  PUT /api/khunggio/:id
//  Cập nhật trạng thái slot (trong ↔ da_dat) hoặc giờ
//  Body: { trangThai?, gioBatDau?, gioKetThuc?, ghiChu? }
// ─────────────────────────────────────────────────────
router.put('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { trangThai, gioBatDau, gioKetThuc, ghiChu } = req.body;

    const [existing] = await db.query('SELECT * FROM khung_gio_kham WHERE id = ?', [id]);
    if (existing.length === 0)
      return res.status(404).json({ success: false, message: 'Không tìm thấy slot' });

    const r = existing[0];
    await db.query(
      'UPDATE khung_gio_kham SET trang_thai = ?, gio_bat_dau = ?, gio_ket_thuc = ?, ghi_chu = ? WHERE id = ?',
      [
        trangThai  ?? r.trang_thai,
        gioBatDau  ?? r.gio_bat_dau,
        gioKetThuc ?? r.gio_ket_thuc,
        ghiChu     !== undefined ? ghiChu : r.ghi_chu,
        id,
      ]
    );

    res.json({ success: true, message: 'Cập nhật thành công', data: { id, trangThai: trangThai ?? r.trang_thai } });
  } catch (err) {
    console.error('PUT /api/khunggio lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

// ─────────────────────────────────────────────────────
//  DELETE /api/khunggio/:id
//  Xóa 1 slot theo id
// ─────────────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [existing] = await db.query('SELECT * FROM khung_gio_kham WHERE id = ?', [id]);
    if (existing.length === 0)
      return res.status(404).json({ success: false, message: 'Không tìm thấy slot' });

    await db.query('DELETE FROM khung_gio_kham WHERE id = ?', [id]);

    const r = existing[0];
    res.json({
      success: true,
      message: `Đã xóa slot ${r.gio_bat_dau} ngày ${r.thu}`,
      data: { id, thu: r.thu, gioBatDau: r.gio_bat_dau }
    });
  } catch (err) {
    console.error('DELETE /api/khunggio lỗi:', err.message);
    res.status(500).json({ success: false, message: 'Lỗi server', error: err.message });
  }
});

module.exports = router;
