// controllers/bacSiController.js
const db = require('../config/db');

const toInt = (v, fallback) => {
  const n = parseInt(v, 10);
  return isNaN(n) ? fallback : n;
};

// GET /api/bac-si
// Query: ?page=1&limit=10&search=nguyễn&khoa_id=1
exports.getAll = async (req, res) => {
  try {
    const page    = toInt(req.query.page,   1);
    const limit   = toInt(req.query.limit, 10);
    const search  = (req.query.search || '').trim();
    const khoaId  = req.query.khoa_id ? toInt(req.query.khoa_id, null) : null;
    const offset  = (page - 1) * limit;

    const conditions = [];
    const params     = [];

    if (search) {
      conditions.push('(b.ho_ten LIKE ? OR b.chuyen_mon LIKE ? OR b.email LIKE ? OR b.so_dien_thoai LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (khoaId) {
      conditions.push('b.khoa_id = ?');
      params.push(khoaId);
    }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';

    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) AS total FROM bac_si b ${where}`,
      params
    );

    const [rows] = await db.query(
      `SELECT b.*, k.ten_khoa
       FROM bac_si b
       LEFT JOIN khoa k ON k.id = b.khoa_id
       ${where}
       ORDER BY b.id
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    res.json({
      success: true,
      data: rows,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/bac-si/:id
exports.getById = async (req, res) => {
  try {
    const [[row]] = await db.query(
      `SELECT b.*, k.ten_khoa
       FROM bac_si b
       LEFT JOIN khoa k ON k.id = b.khoa_id
       WHERE b.id = ?`,
      [req.params.id]
    );

    if (!row) return res.status(404).json({ success: false, message: 'Không tìm thấy bác sĩ' });

    res.json({ success: true, data: row });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /api/bac-si
exports.create = async (req, res) => {
  try {
    const { ho_ten, chuyen_mon, so_dien_thoai, email, khoa_id } = req.body;

    if (!ho_ten || !ho_ten.trim()) {
      return res.status(400).json({ success: false, message: 'Họ tên không được để trống' });
    }

    // Kiểm tra email trùng
    if (email) {
      const [[exists]] = await db.query(
        'SELECT id FROM bac_si WHERE email = ?',
        [email.trim()]
      );
      if (exists) {
        return res.status(400).json({ success: false, message: 'Email đã tồn tại' });
      }
    }

    // Kiểm tra khoa tồn tại
    if (khoa_id) {
      const [[khoa]] = await db.query('SELECT id FROM khoa WHERE id = ?', [khoa_id]);
      if (!khoa) {
        return res.status(400).json({ success: false, message: 'Khoa không tồn tại' });
      }
    }

    const [result] = await db.query(
      'INSERT INTO bac_si (ho_ten, chuyen_mon, so_dien_thoai, email, khoa_id) VALUES (?, ?, ?, ?, ?)',
      [ho_ten.trim(), chuyen_mon || null, so_dien_thoai || null, email || null, khoa_id || null]
    );

    res.status(201).json({
      success: true,
      message: 'Thêm bác sĩ thành công',
      data: { id: result.insertId, ho_ten, chuyen_mon, so_dien_thoai, email, khoa_id },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// PUT /api/bac-si/:id
exports.update = async (req, res) => {
  try {
    const { ho_ten, chuyen_mon, so_dien_thoai, email, khoa_id } = req.body;

    if (!ho_ten || !ho_ten.trim()) {
      return res.status(400).json({ success: false, message: 'Họ tên không được để trống' });
    }

    // Kiểm tra email trùng (loại trừ bản ghi hiện tại)
    if (email) {
      const [[exists]] = await db.query(
        'SELECT id FROM bac_si WHERE email = ? AND id != ?',
        [email.trim(), req.params.id]
      );
      if (exists) {
        return res.status(400).json({ success: false, message: 'Email đã tồn tại' });
      }
    }

    const [result] = await db.query(
      'UPDATE bac_si SET ho_ten=?, chuyen_mon=?, so_dien_thoai=?, email=?, khoa_id=? WHERE id=?',
      [ho_ten.trim(), chuyen_mon || null, so_dien_thoai || null, email || null, khoa_id || null, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy bác sĩ' });
    }

    res.json({ success: true, message: 'Cập nhật bác sĩ thành công' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE /api/bac-si/:id
exports.remove = async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM bac_si WHERE id=?', [req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy bác sĩ' });
    }

    res.json({ success: true, message: 'Xóa bác sĩ thành công' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
