
var builder = WebApplication.CreateBuilder(args);

// 👉 THÊM DÒNG NÀY (QUAN TRỌNG)
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy => policy.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader());
});

var app = builder.Build();

app.UseStaticFiles();

app.UseCors("AllowAll");

app.MapControllers();

app.Run();