require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  port:               Number(process.env.DB_PORT) || 3306,
  user:               process.env.DB_USER     || 'root',
  password:           process.env.DB_PASSWORD || '',
  database:           process.env.DB_NAME     || 'clinicare',
  waitForConnections: true,
  connectionLimit:    10,
  charset:            'utf8mb4',
});

// Kiểm tra kết nối ngay khi khởi động
pool.getConnection()
  .then(conn => {
    console.log('✅ Kết nối MySQL thành công!');
    conn.release();
  })
  .catch(err => {
    console.error('❌ Kết nối MySQL thất bại:', err.message);
    console.error('👉 Mở file .env và kiểm tra DB_HOST, DB_USER, DB_PASSWORD');
    process.exit(1);
  });

module.exports = pool;
