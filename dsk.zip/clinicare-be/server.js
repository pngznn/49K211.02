require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const khoaRoutes = require('./routes/khoa');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ──────────────────────────────
app.use(cors());          // Cho phép FE (port 5500) gọi sang BE (port 3000)
app.use(express.json());  // Đọc JSON từ request body

// ── Routes ──────────────────────────────────
app.use('/api/khoa', khoaRoutes);

// Route kiểm tra server còn sống không
app.get('/', (req, res) => {
  res.json({ message: '✅ CliniCare API đang chạy!', version: '1.0.0' });
});

// ── Khởi động ───────────────────────────────
app.listen(PORT, () => {
  console.log('');
  console.log('================================================');
  console.log('  🚀 CliniCare Backend đang chạy!');
  console.log(`  📡 Server : http://localhost:${PORT}`);
  console.log(`  📋 API    : http://localhost:${PORT}/api/khoa`);
  console.log('================================================');
  console.log('');
});
