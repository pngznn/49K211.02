require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  port:               Number(process.env.DB_PORT) || 3306,
  user:               process.env.DB_USER     || 'root',
  password:           process.env.DB_PASSWORD || '',
  database:           process.env.DB_NAME     || 'clinicare',
  waitForConnections: true,
  connectionLimit:    10,
  charset:            'utf8mb4',
});

pool.getConnection()
  .then(conn => {
    console.log('✅ Kết nối MySQL thành công!');
    conn.release();
  })
  .catch(err => {
    console.error('❌ Kết nối MySQL thất bại:', err.message);
    console.error('👉 Kiểm tra lại .env: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME');
    process.exit(1);
  });

module.exports = pool;
